"""
Participant source package initialization.
"""
